# Twitter Clone Backend

## Assignment Overview
This project is a simplified backend system for a Twitter-like application. It is built using Node.js and MongoDB, focusing on scalability, performance, maintainability, and Domain-Driven Design (DDD) principles.

## How to Run the Application

### Dependencies
- Node.js
- MongoDB

### Installation Instructions

1. Clone the repository
    ```bash
    git clone https://github.com/your-username/twitter-clone-backend.git
    cd twitter-clone-backend
    ```

2. Install the dependencies
    ```bash
    npm install
    ```

3. Set up MongoDB
    - Ensure MongoDB is running on your local machine or configure the `config/db.js` file to connect to your MongoDB instance.

4. Run the application
    ```bash
    npm start
    ```

### Configuration
- No additional configuration is required for this setup.

### API Endpoints

1. **User Registration**
    - **Endpoint**: `POST /api/users/register`
    - **Body**: `{ "username": "string", "password": "string" }`
    - **Response**: `201 Created` or `500 Error`

2. **User Login**
    - **Endpoint**: `POST /api/users/login`
    - **Body**: `{ "username": "string", "password": "string" }`
    - **Response**: `{ "token": "string" }` or `401 Unauthorized`

3. **Post a Tweet**
    - **Endpoint**: `POST /api/tweets`
    - **Body**: `{ "token": "string", "text": "string" }`
    - **Response**: `201 Created` or `500 Error`

4. **Fetch User Timeline**
    - **Endpoint**: `GET /api/users/:userId/timeline`
    - **Response**: `[ { "userId": "ObjectId", "text": "string", "createdAt": "Date" } ]` or `500 Error`

### Testing
- No automated tests are provided for this assignment.

### Issues and Troubleshooting
- Ensure MongoDB is running and accessible.
- Check that the JWT secret key matches between the token generation and validation.

### Contact Information
For any queries or assistance, please contact [Your Name] at [your-email@example.com].


