const Tweet = require('../models/Tweet');

exports.postTweet = async (userId, text) => {
    const tweet = new Tweet({ userId, text, createdAt: new Date() });
    await tweet.save();
};

exports.getUserTimeline = async (userId) => {
    return Tweet.find({ userId }).sort({ createdAt: -1 });
};
