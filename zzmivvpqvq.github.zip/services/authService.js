const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.register = async (username, password) => {
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ username, password: hashedPassword });
    await user.save();
};

exports.login = async (username, password) => {
    const user = await User.findOne({ username });
    if (!user || !await bcrypt.compare(password, user.password)) {
        throw new Error('Invalid credentials');
    }
    return jwt.sign({ userId: user._id }, 'secret_key', { expiresIn: '1h' });
};
