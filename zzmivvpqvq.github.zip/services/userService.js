// Additional user-related services can go here
