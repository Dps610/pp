const express = require('express');
const router = express.Router();
// User routes can be added here

module.exports = router;
