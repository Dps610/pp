const authService = require('../services/authService');
const errorHandler = require('../utils/errorHandler');

exports.register = async (req, res) => {
    try {
        const { username, password } = req.body;
        await authService.register(username, password);
        res.status(201).send('User registered');
    } catch (err) {
        errorHandler(err, res);
    }
};

exports.login = async (req, res) => {
    try {
        const { username, password } = req.body;
        const token = await authService.login(username, password);
        res.json({ token });
    } catch (err) {
        errorHandler(err, res);
    }
};
