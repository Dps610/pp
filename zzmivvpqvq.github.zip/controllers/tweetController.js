const tweetService = require('../services/tweetService');
const errorHandler = require('../utils/errorHandler');

exports.postTweet = async (req, res) => {
    try {
        const { userId, text } = req.body;
        await tweetService.postTweet(userId, text);
        res.status(201).send('Tweet posted');
    } catch (err) {
        errorHandler(err, res);
    }
};

exports.getUserTimeline = async (req, res) => {
    try {
        const { userId } = req.params;
        const tweets = await tweetService.getUserTimeline(userId);
        res.json(tweets);
    } catch (err) {
        errorHandler(err, res);
    }
};
